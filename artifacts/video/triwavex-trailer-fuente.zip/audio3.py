import numpy as np, soundfile as sf, json
from scipy.signal import butter, sosfilt, fftconvolve, resample_poly
sr=44100; DUR=62.0; N=int(sr*DUR); rng=np.random.default_rng(11)
tm=json.load(open('timing3.json')); T=tm['T']; TAPS=tm['TAPS']
def lp(x,f,o=2): return sosfilt(butter(o,f,'low',fs=sr,output='sos'),x)
def hp(x,f,o=2): return sosfilt(butter(o,f,'high',fs=sr,output='sos'),x)
def bp(x,a,b): return sosfilt(butter(2,[a,b],'band',fs=sr,output='sos'),x)
def add(buf,x,t):
    i=int(round(t*sr))
    if i<0: x=x[-i:]; i=0
    n=min(len(x),len(buf)-i)
    if n>0: buf[i:i+n]+=x[:n]
def env(n,a,d):
    t=np.arange(n)/sr; return np.minimum(t/max(a,1e-4),1)*np.exp(-t/d)
f=lambda m:440*2**((m-69)/12)
beat=.5; bar=2.0
chords=[[57,60,64],[53,57,60],[48,55,60],[43,55,59]]  # Am F C G
def ch(t): return chords[int(t//bar)%4]
pad=np.zeros(N); bass=np.zeros(N); arp=np.zeros(N); drums=np.zeros(N); fx=np.zeros(N); vo=np.zeros(N)
kicks=[]
def kick(t,a=.9):
    n=int(sr*.3); tt=np.arange(n)/sr
    add(drums,np.sin(2*np.pi*(48+110*np.exp(-tt*28))*tt)*np.exp(-tt*9)*a,t); kicks.append(t)
def clap(t,a=.35):
    n=int(sr*.2); x=bp(rng.standard_normal(n),900,3800)*env(n,.002,.06)
    add(drums,x*a*2.2,t)
def hat(t,a=.10,d=.012,o=False):
    n=int(sr*(.16 if o else .06)); add(drums,hp(rng.standard_normal(n),7500)*env(n,.001,.05 if o else d)*a,t)
def sawv(fr,n):
    tt=np.arange(n)/sr; return 2*((tt*fr)%1)-1
def pluck(m,t,a=.10,d=.16):
    n=int(sr*.5); x=(sawv(f(m),n)*.6+np.sin(2*np.pi*f(m)*np.arange(n)/sr)*.6)
    add(arp,lp(x,3500)*env(n,.003,d)*a,t)
def piano(m,t,a=.16):
    n=int(sr*2.2); tt=np.arange(n)/sr
    x=np.sin(2*np.pi*f(m)*tt)+.35*np.sin(4*np.pi*f(m)*tt)*np.exp(-tt*3)+.15*np.sin(6*np.pi*f(m)*tt)*np.exp(-tt*5)
    add(arp,x*env(n,.004,.9)*a,t)
def boom(t,a=.9,l=1.6):
    n=int(sr*l); tt=np.arange(n)/sr
    add(fx,np.sin(2*np.pi*(38+40*np.exp(-tt*5))*tt)*np.exp(-tt*2.2)*a,t)
    add(fx,hp(rng.standard_normal(n),2500)*np.exp(-tt*3.0)*a*.22,t)
def riser(t0,dur,a=.3):
    n=int(sr*dur); x=rng.standard_normal(n); out=np.zeros(n); seg=n//24
    for i in range(24):
        c=250*(1.22**i); s=bp(x[i*seg:(i+1)*seg+1],min(c,9000),min(c*2.5,12000)); out[i*seg:i*seg+len(s)]=s
    add(fx,out*(np.linspace(0,1,n)**2)*a*3,t0)
def whoosh(t0,dur=.5,a=.30):
    n=int(sr*dur); x=rng.standard_normal(n); out=np.zeros(n); seg=n//10
    for i in range(10):
        c=400*(1.25**i); s=bp(x[i*seg:(i+1)*seg+1],max(c,200),min(c*2.2,9000)); out[i*seg:i*seg+len(s)]=s
    add(fx,out*np.sin(np.linspace(0,np.pi,n))**2*a*3,t0)
def click(t0):
    n=int(sr*.06); tt=np.arange(n)/sr
    add(fx,np.sin(2*np.pi*2000*tt)*np.exp(-tt*90)*.18+hp(rng.standard_normal(n),3000)*np.exp(-tt*120)*.15,t0)
def ding(t0,notes=(79,84),amp=.22):
    for i,m in enumerate(notes):
        n=int(sr*.9); tt=np.arange(n)/sr; add(fx,np.sin(2*np.pi*f(m)*tt)*env(n,.003,.25)*amp,t0+i*.09)

# ---- pad (whole piece) ----
t=0
while t<DUR:
    c=ch(t); n=int(sr*(bar+1.0)); p=np.zeros(n)
    for m in c:
        for det in (-.12,.12): p+=sawv(f(m+12)*2**(det/12),n)*.045
        p+=np.sin(2*np.pi*f(m)*np.arange(n)/sr)*.06
    e=np.minimum(np.arange(n)/sr/.5,1)*np.exp(-np.maximum(np.arange(n)/sr-bar,0)/.35)
    add(pad,lp(p,1500)*e,t); t+=bar
# ---- A: cold open ----
tt=np.arange(int(sr*4.0))/sr
drone=(np.sin(2*np.pi*f(33)*tt)*.35+np.sin(2*np.pi*f(45)*tt)*.18)*np.minimum(tt/1.5,1)*(1+.2*np.sin(tt*3))
add(fx,drone*.6,0)
for hb in [.3,.62,1.05,1.36,1.75,2.05,2.4,2.66,3.0,3.24]:
    n=int(sr*.14); t2=np.arange(n)/sr; add(fx,np.sin(2*np.pi*58*t2)*np.exp(-t2*24)*.55,hb)
riser(.3,3.6,.30)
rt=3.0
while rt<3.92:
    n=int(sr*.12); add(fx,bp(rng.standard_normal(n),1200,5000)*env(n,.002,.05)*.30,rt); rt+=max(.06,.25*(1-(rt-3.0)/1.0)+.05)
# ---- B..F grooves ----
def groove(t0,t1,hats=True,clp=True,ar=True,arg=1.0,bs=True):
    t=t0
    while t<t1-1e-6:
        kick(t)
        if hats: hat(t+beat/2,.11,o=True); hat(t+beat/4,.05); hat(t+3*beat/4,.05)
        if clp and (int(round((t-t0)/beat))%2==1): clap(t)
        if bs:
            c=ch(t); n=int(sr*.24); root=c[0]-12
            for k in (0,1): add(bass,np.sin(2*np.pi*f(root)*np.arange(n)/sr)*env(n,.005,.16)*.5+ lp(sawv(f(root),n),400)*env(n,.005,.12)*.25, t+k*beat/2)
        if ar:
            c=ch(t); seq=[c[0]+12,c[1]+12,c[2]+12,c[0]+24]
            for k in range(4):
                pluck(seq[[0,2,1,3][k]] if k%2==0 else seq[[1,3,2,0][k]],t+k*beat/4,a=.10*arg)
        t+=beat
kick(T['b'],1.0)
groove(T['b'],T['c1'],hats=False,clp=False,ar=False)          # logo: kick+bass+pad
groove(5.0,T['c1'],hats=True,clp=False,ar=False) if False else None
groove(T['c1'],T['e7'],arg=1.0)                                # sports + app
# breakdown 52-55: emotional piano
for i,tp in enumerate(np.arange(T['e7'],T['s8'],beat)):
    c=ch(tp); piano([c[0]+12,c[1]+12,c[2]+12,c[1]+24][i%4],tp,a=.16)
piano(45,T['e7'],.12)
groove(T['s8'],60.0,arg=1.1)
# impacts and risers
for k in ('c1','c2','c3'): boom(T[k],.7); riser(T[k]-.5,.5,.22)
boom(T['b'],1.0,2.0); boom(T['s3'],.55); boom(T['s8'],.95,2.0); riser(T['s8']-.5,.5,.25)
# end tail chord + fade
for m in (57,60,64,69):
    n=int(sr*3); tt2=np.arange(n)/sr; add(pad,np.sin(2*np.pi*f(m)*tt2)*.06*np.exp(-tt2*.8),60.0)
# sfx
for k in ['s3','f1','s4','f2','s5','f3','s6','f4','s7','e']: whoosh(T[k]-.25)
for t0 in TAPS: click(t0)
ding(TAPS[4]+.1,(79,86),.25)
for t0 in (T['s6']+.7*.6875,T['s6']+2.4*.6875,T['s6']+4.7*.6875): add(fx,np.sin(2*np.pi*f(88)*np.arange(int(sr*.25))/sr)*env(int(sr*.25),.003,.06)*.12,t0)
for t0 in TAPS[7:10]: ding(t0+.05,(81,88),.14)
ding(T['s8']+.3,(72,79,84),.16)
# ---- voice ----
starts=[T['b']+.5,T['c1']+.3,T['s3']+.3,T['e']+.4,T['s8']+.6]
def reverb(x,wet=.13,l=.9):
    n=int(sr*l); ir=rng.standard_normal(n)*np.exp(-np.arange(n)/sr*5.0); ir=lp(ir,6000)
    ir/=np.sqrt(np.sum(ir**2)); return x*(1-wet)+fftconvolve(x,ir)[:len(x)]*wet*1.6
for i,s in enumerate(starts):
    x,r=sf.read(f'vo3/{i}.wav')
    if r!=sr: x=resample_poly(x,sr,r)
    x=hp(x,90,2)
    # warmth: low shelf boost + gentle presence trim
    x=x+lp(x,220)*.35; x=x-bp(x,5000,9000)*.25
    x=np.pad(x,(0,int(sr*1.0)))
    x=reverb(x)
    x=np.tanh(x*1.7)/np.tanh(1.7)        # soft compress
    add(vo,x,s)
vo=vo/np.max(np.abs(vo))*0.92
# ---- sidechain ----
kk=np.zeros(N)
for tk in kicks:
    i=int(tk*sr); n=min(int(sr*.35),N-i)
    if n>0: kk[i:i+n]=np.maximum(kk[i:i+n],np.exp(-np.arange(n)/sr/.11))
duck=1-.55*kk
music=(pad*.9+bass*1.0+arp*1.0)*duck+drums*.85
e=np.abs(vo); win=int(sr*.06); e=np.convolve(e,np.ones(win)/win,'same'); e=np.clip(e*8,0,1); e=lp(e,6,1)
music*=1-.45*np.clip(e,0,1)
mix=music*.9+fx*.95+vo*1.05
mix=lp(mix,16000)
fade=np.ones(N); i0=int((DUR-2.5)*sr); fade[i0:]=np.linspace(1,0,N-i0)**1.6; mix*=fade
mix=np.tanh(mix*1.15)/np.tanh(1.15); mix/=np.max(np.abs(mix))/.9
sf.write('mix3.wav',np.stack([mix,mix],1),sr); print('ok',np.sqrt(np.mean(mix**2)))
