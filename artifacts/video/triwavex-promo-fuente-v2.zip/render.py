import sys,os
from playwright.sync_api import sync_playwright
w,nw,total,fps=int(sys.argv[1]),int(sys.argv[2]),int(sys.argv[3]),30
D='/tmp/claude-0/-home-claude/11c37f9c-3ec2-507b-929b-846ec942a76c/scratchpad/v'
os.makedirs(f'{D}/frames',exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.goto(f'file://{D}/site/index.html'); pg.wait_for_function('window.ready===true')
    for i in range(w,total,nw):
        pg.evaluate(f'seek({i/fps})')
        pg.evaluate("(async()=>{const i=document.getElementById('cv');if(i.getAttribute('src')){try{await i.decode()}catch(e){}}})()")
        pg.screenshot(path=f'{D}/frames/{i:05d}.jpg',type='jpeg',quality=92)
    b.close()
print('done',w)
