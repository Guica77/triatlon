import numpy as np, soundfile as sf, json
from scipy.signal import butter, sosfilt, lfilter
sr=44100; DUR=51.6; N=int(sr*DUR); rng=np.random.default_rng(3)
tm=json.load(open('timing.json')); T=tm['T']; TAPS=tm['TAPS']
def lp(x,f,o=2): return sosfilt(butter(o,f,'low',fs=sr,output='sos'),x)
def hp(x,f,o=2): return sosfilt(butter(o,f,'high',fs=sr,output='sos'),x)
def bp(x,a,b): return sosfilt(butter(2,[a,b],'band',fs=sr,output='sos'),x)
def add(buf,x,t):
    i=int(t*sr); 
    if i<0: x=x[-i:]; i=0
    n=min(len(x),len(buf)-i)
    if n>0: buf[i:i+n]+=x[:n]
def env(n,a,d): 
    t=np.arange(n)/sr; return np.minimum(t/max(a,1e-4),1)*np.exp(-t/d)
mus=np.zeros(N); sfx=np.zeros(N)
f=lambda m:440*2**((m-69)/12)
chords=[[57,60,64],[53,57,60],[48,55,60],[43,55,59]]  # Am F C G
beat=0.6; bar=beat*4
def saw(fr,n): 
    t=np.arange(n)/sr; return 2*((t*fr)%1)-1
# pad
t=0; ci=0
while t<DUR:
    ch=chords[ci%4]; n=int(sr*(bar+1.2)); pad=np.zeros(n)
    for m in ch:
        for det in (-.15,.15):
            pad+=saw(f(m+12)*2**(det/12),n)*0.05+np.sin(2*np.pi*f(m)*np.arange(n)/sr)*0.06
    e=np.minimum(np.arange(n)/sr/0.9,1)*np.exp(-np.maximum(np.arange(n)/sr-bar,0)/0.5)
    add(mus,lp(pad,1400)*e*0.9,t); t+=bar; ci+=1
# bass, kick, hat, arp from s2 / s3
t=T['s2']; 
while t<DUR-2:
    ci=int(t//bar); ch=chords[ci%4]; n=int(sr*0.55)
    b=np.sin(2*np.pi*f(ch[0]-12)*np.arange(n)/sr)*env(n,.01,.35)*0.5
    if int((t%bar)/beat+.01)%2==0: add(mus,b,t)
    t+=beat
t=T['s3']
while t<DUR-2.2:
    n=int(sr*0.28); tt=np.arange(n)/sr
    k=np.sin(2*np.pi*(45+90*np.exp(-tt*30))*tt)*np.exp(-tt*11)*0.75; add(mus,k,t)
    h=hp(rng.standard_normal(int(sr*.05)),7000)*env(int(sr*.05),.001,.012)*0.12; add(mus,h,t+beat/2)
    t+=beat
t=T['s3']+beat/2; k=0
while t<DUR-2.2:
    ci=int(t//bar); ch=chords[ci%4]; m=ch[k%3]+12+(12 if k%4==3 else 0)
    n=int(sr*.4); tt=np.arange(n)/sr
    p=(np.sin(2*np.pi*f(m)*tt)+.3*np.sin(4*np.pi*f(m)*tt))*env(n,.004,.12)*0.11
    add(mus,p,t); t+=beat/2; k+=1
# intro riser
n=int(sr*3.4); r=lp(rng.standard_normal(n),3000)*np.linspace(0,1,n)**3*0.15; add(mus,hp(r,600),0.2)
# end: fade
fade=np.ones(N); i0=int((DUR-3)*sr); fade[i0:]=np.linspace(1,0,N-i0)**1.5; mus*=fade
# sfx
def whoosh(t0,dur=.55,amp=.35):
    n=int(sr*dur); x=rng.standard_normal(n); out=np.zeros(n)
    seg=n//10
    for i in range(10):
        c=400*(1.25**i)*(1 + 0); s=bp(x[i*seg:(i+1)*seg+1],max(c,200),min(c*2.2,9000)); out[i*seg:i*seg+len(s)]=s
    e=np.sin(np.linspace(0,np.pi,n))**2; add(sfx,out*e*amp*3,t0)
for k in ['s2','s3','s4','s5','s6','s7','s8']: whoosh(T[k]-.3)
def click(t0):
    n=int(sr*.06); tt=np.arange(n)/sr
    add(sfx,(np.sin(2*np.pi*2000*tt)*np.exp(-tt*90)*.18+hp(rng.standard_normal(n),3000)*np.exp(-tt*120)*.15),t0)
for t0 in TAPS: click(t0)
def ding(t0,notes=(79,84),amp=.22):
    for i,m in enumerate(notes):
        n=int(sr*.9); tt=np.arange(n)/sr
        add(sfx,np.sin(2*np.pi*f(m)*tt)*env(n,.003,.25)*amp,t0+i*.09)
ding(12.1+.1,(79,86),.25)
for t0 in (29.3,31.0,33.3): add(sfx,np.sin(2*np.pi*f(88)*np.arange(int(sr*.25))/sr)*env(int(sr*.25),.003,.06)*.12,t0)
for t0 in (38.8,40,41.2): ding(t0+.05,(81,88),.14)
ding(T['s8']+.5,(72,79,84),.16)
# voice
starts=[0.6,3.9,9.0,15.0,22.0,29.0,37.0,44.2]
vo=np.zeros(N)
for i,s in enumerate(starts):
    x,r=sf.read(f'vo/{i}.wav'); 
    if r!=sr:
        from scipy.signal import resample_poly; x=resample_poly(x,sr,r)
    x=hp(x,70,2)*1.0; add(vo,x,s)
vo=vo/np.max(np.abs(vo))*0.9
# ducking
e=np.abs(vo); win=int(sr*.05); e=np.convolve(e,np.ones(win)/win,'same'); e=np.clip(e*8,0,1)
e=lp(e,6,1); duck=1-0.55*np.clip(e,0,1)
mus=mus*duck
mus=lp(mus,12000)
mix=mus*0.85+sfx*0.9+vo*1.0
mix=np.tanh(mix*1.1)/np.tanh(1.1); mix=mix/np.max(np.abs(mix))*0.89
sf.write('mix.wav',np.stack([mix,mix],1),sr)
print('ok',np.sqrt(np.mean(mix**2)))
