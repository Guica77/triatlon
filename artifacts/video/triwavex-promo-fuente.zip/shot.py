import sys,asyncio
from playwright.sync_api import sync_playwright
times=[float(x) for x in sys.argv[1:]]
with sync_playwright() as p:
    b=p.chromium.launch(); pg=b.new_page(viewport={'width':1080,'height':1920})
    pg.on('console',lambda m:print('console',m.text)); pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///tmp/claude-0/-home-claude/11c37f9c-3ec2-507b-929b-846ec942a76c/scratchpad/v/site/index.html')
    pg.wait_for_function('window.ready===true')
    for t in times:
        pg.evaluate(f'seek({t})'); pg.screenshot(path=f'/tmp/claude-0/-home-claude/11c37f9c-3ec2-507b-929b-846ec942a76c/scratchpad/v/f_{t}.png')
    b.close()
